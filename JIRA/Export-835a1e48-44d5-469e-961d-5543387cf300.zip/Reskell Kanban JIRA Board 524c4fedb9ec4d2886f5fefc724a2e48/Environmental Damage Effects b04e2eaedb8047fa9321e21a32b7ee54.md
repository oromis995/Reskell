# Environmental Damage Effects

Assign: Anonymous
Epic: Effects
Estimate: 13
Sprint: 2
Status: Not started