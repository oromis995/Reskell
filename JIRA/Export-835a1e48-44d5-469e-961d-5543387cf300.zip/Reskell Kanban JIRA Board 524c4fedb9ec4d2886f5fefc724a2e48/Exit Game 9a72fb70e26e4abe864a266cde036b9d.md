# Exit Game

Definition Of Done: - Pressing Exit Game closes the game
- Pressing Exit Game prompts to save if the player has a scene open.
Epic: Main Menu
Sprint: 1
Status: In progress
Story: As Player, I want to access press Exit Game in the main menu, so that I can exit.