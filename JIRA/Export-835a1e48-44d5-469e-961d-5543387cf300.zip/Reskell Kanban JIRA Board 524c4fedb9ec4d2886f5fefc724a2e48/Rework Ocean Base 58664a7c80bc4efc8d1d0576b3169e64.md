# Rework Ocean Base

Assign: Anonymous
Date: November 22, 2021 → December 2, 2021
Epic: Environment
Estimate: 13
Sprint: 2
Status: In progress