# Work on making the lights flicker

Assign: Anonymous
Date: December 1, 2021 → December 2, 2021
Epic: Effects
Estimate: 13
Sprint: 2
Status: In progress