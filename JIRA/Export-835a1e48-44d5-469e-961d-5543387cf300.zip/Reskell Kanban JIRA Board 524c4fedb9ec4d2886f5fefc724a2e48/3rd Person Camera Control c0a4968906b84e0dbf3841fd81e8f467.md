# 3rd Person Camera Control

Assign: Anonymous
Date: October 25, 2021 → October 28, 2021
Definition Of Done: -X,Y,Z shifting, preset, or control of camera focus on character.
-Left or right oriented camera
Epic: Mechanics
Estimate: 5
Priority: Thunderstorm
Sprint: 1
Status: Completed
Story: As a user I want to have a comfortable camera spacing/preset, so that I can see the beautiful Chad I created at different angles.