# Rain and Environmental Effects

Assign: Anonymous
Date: October 30, 2021 → November 5, 2021
Epic: Effects
Estimate: 8
Sprint: 1
Status: Completed