# New Game

Definition Of Done: - Pressing New Game closes the main menu
- Pressing New Game opens the opening scene
Epic: Main Menu
Sprint: 1
Status: Completed
Story: As Player, I want to press New Game in the main menu, so that I can play.