# Character Appearance

Assign: Anonymous
Date: October 31, 2021 → November 3, 2021
Definition Of Done: - A main character must be the default, either male or female, but one to start off with
Epic: Characters
Estimate: 5
Sprint: 1
Status: Completed
Story: As Player, I want to have a character with clothes and hair, so that I can not freak out