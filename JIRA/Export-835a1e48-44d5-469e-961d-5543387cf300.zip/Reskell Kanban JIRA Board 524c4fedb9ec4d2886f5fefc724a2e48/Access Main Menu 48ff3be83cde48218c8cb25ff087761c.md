# Access Main Menu

Definition Of Done: - Pauses the game.
- Allows player to access: save, load, options, and exit the game.
Epic: Main Menu
Sprint: 1
Status: Completed
Story: As Player, I want to press New Game in the main menu, so that I can play.